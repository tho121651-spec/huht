// Menu chính - giữ nguyên nhóm, thứ tự và đường dẫn của hệ thống gốc
export const mainMenu = [
  {
    label: 'Hỗ trợ hoạt động học tập',
    items: [
      { type: 'header', label: 'Kế hoạch học tập' },
      { type: 'link', label: 'Đăng ký học tập', to: '/Studying/Modules' },
      { type: 'link', label: 'Lớp học phần đã đăng ký', to: '/Studying/RegisteredCourses' },
      { type: 'link', label: 'Lịch trình học tập', to: '/TimeTable' },
      { type: 'link', label: 'Lịch thi kết thúc học phần', to: '/Studying/ScheduleOfExam' },

      { type: 'header', label: 'Hỗ trợ - Tra cứu thông tin' },
      { type: 'link', label: 'Chương trình đào tạo', to: '/TrainingProgram' },

      { type: 'header', label: 'Số liệu - Tổng hợp' },
      { type: 'link', label: 'Lịch sử quá trình học tập', to: '/Statistics/HistoryOfStudying' },
      { type: 'link', label: 'Kết quả học tập', to: '/Statistics/StudyResult' },
      { type: 'link', label: 'Kết quả rèn luyện', to: '/Statistics/Conduct' },

      { type: 'header', label: 'Đảm bảo chất lượng giáo dục' },
      { type: 'link', label: 'Khảo sát hoạt động giảng dạy', to: '/Survey' }
    ]
  },
  {
    label: 'Học phí - Lệ phí',
    items: [
      { type: 'link', label: 'Nộp học phí trực tuyến', to: '/Tuition/Payment' },
      { type: 'link', label: 'Nộp học phí (sử dụng QRCode)', to: '/Tuition/PaymentQR' },
      { type: 'divider' },
      { type: 'link', label: 'Tra cứu lịch sử nộp học phí', to: '/Tuition/History' }
    ]
  }
]

// Khối "CÁC CHỨC NĂNG CHUNG" ở cột trái
export const generalFunctions = [
  { id: 'linkNews', icon: 'book', label: 'Tin tức - Thông báo', to: '/News', badge: 'notification-news' },
  { id: 'linkCalendar', icon: 'calendar', label: 'Thời khóa biểu học tập', to: '/TimeTable/Week', badge: 'notification-calendar' },
  { id: 'linkMessage', icon: 'message', label: 'Tin nhắn', to: '/Message/Inbox', badge: 'notification-message' }
]

// Khối tài khoản ở cột trái
export const accountLinks = [
  { id: 'link_userProfile', icon: 'people', label: 'Lý lịch cá nhân', to: '/Account/UserProfile' },
  { id: 'link_userPassword', icon: 'key', label: 'Đổi mật khẩu', to: '/Account/ChangePassword' },
  { id: 'link_userLogout', icon: 'logout', label: 'Đăng xuất', to: '/Account/Logout', confirm: 'Thoát khỏi hệ thống' }
]
