import { Navigate, Route, Routes } from 'react-router-dom'
import Header from './components/Header.jsx'
import Navbar from './components/Navbar.jsx'
import StatusBar from './components/StatusBar.jsx'
import Sidebar from './components/Sidebar.jsx'
import Footer from './components/Footer.jsx'
import StudentPortal from './pages/StudentPortal.jsx'
import NewsDetail from './pages/NewsDetail.jsx'
import Schedule from './pages/Schedule.jsx'

export default function App() {
  return (
    <>
      {/* Header and Menu */}
      <div className="container-fluid">
        <Header />
        <Navbar />
        <StatusBar />
      </div>

      {/* Panel left and main content */}
      <div className="container-fluid" id="wrapper">
        <div className="panel-sidebar-left">
          <Sidebar />
        </div>

        <div className="panel-main-content">
          <div className="hitec-content">
            <div className="row">
              <div className="col-xs-12">
                <Routes>
                  <Route path="/" element={<Navigate to="/News" replace />} />
                  <Route path="/News" element={<StudentPortal />} />
                  <Route path="/News/Content/:slug" element={<NewsDetail />} />
                  <Route path="/TimeTable/Week" element={<Schedule />} />
                  <Route path="*" element={<Navigate to="/News" replace />} />
                </Routes>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  )
}
