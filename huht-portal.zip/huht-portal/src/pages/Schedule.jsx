import { useState } from 'react'

const periods = ['Sáng', 'Chiều', 'Tối']
const days = ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ nhật']

// Dữ liệu mẫu, key = `${chỉ số buổi}-${chỉ số thứ}`
const lessons = {
  '0-0': [{ name: 'Quản trị học', code: 'QTKD1013', room: 'A2.03', time: 'Tiết 1 - 3', teacher: 'TS. Nguyễn Văn A' }],
  '0-2': [{ name: 'Marketing căn bản', code: 'QTKD2021', room: 'B1.12', time: 'Tiết 1 - 3', teacher: 'ThS. Lê Thị B' }],
  '1-1': [{ name: 'Kinh tế vi mô', code: 'KTPT1012', room: 'A1.05', time: 'Tiết 7 - 9', teacher: 'TS. Trần Văn C' }],
  '1-4': [{ name: 'Tiếng Anh không chuyên 2', code: 'NNKC2012', room: 'C3.01', time: 'Tiết 7 - 9', teacher: 'ThS. Phạm Thị D' }],
  '2-3': [{ name: 'Giáo dục thể chất', code: 'GDTC1011', room: 'Nhà thi đấu', time: 'Tiết 10 - 12', teacher: 'CN. Hoàng Văn E' }]
}

export default function Schedule() {
  const [week, setWeek] = useState(1)

  return (
    <>
      <h2>THỜI KHÓA BIỂU HỌC TẬP</h2>
      <div className="container-fluid">
        <p>
          <label htmlFor="week" style={{ marginRight: 8 }}>Tuần học</label>
          <select id="week" value={week} onChange={(event) => setWeek(Number(event.target.value))}>
            {Array.from({ length: 20 }, (_, index) => index + 1).map((value) => (
              <option key={value} value={value}>Tuần {value}</option>
            ))}
          </select>
        </p>

        <div className="table-responsive">
          <table className="table table-bordered hitec-timetable">
            <thead>
              <tr>
                <th style={{ width: 90 }}>Buổi</th>
                {days.map((day) => (
                  <th key={day}>{day}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {periods.map((period, row) => (
                <tr key={period}>
                  <th scope="row">{period}</th>
                  {days.map((day, col) => {
                    const items = lessons[`${row}-${col}`]
                    return (
                      <td key={day}>
                        {items &&
                          items.map((lesson) => (
                            <div key={lesson.code} className="hitec-lesson">
                              <strong>{lesson.name}</strong>
                              <br />
                              <small className="text-muted">
                                {lesson.code} · {lesson.time} · Phòng {lesson.room}
                                <br />
                                {lesson.teacher}
                              </small>
                            </div>
                          ))}
                      </td>
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  )
}
